import React from 'react';
import { Route, Routes } from 'react-router-dom';
import UserDirectory from './components/UserDirectory';
import UserProfile from './components/UserProfile';


function App() {
  return (
    <div>
      <Routes>
        <Route path="/" exact element={<UserDirectory />} />
        <Route path="/user/:userId" area="America" location="Argentina" region="Salta" element={< UserProfile />} />
      </Routes>
    </div>
  );
}

export default App;