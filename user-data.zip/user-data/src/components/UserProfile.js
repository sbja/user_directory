import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import './UserProfile.scss'
import ProfilePage from './Clock';
import "./UserCard.scss"


const UserProfile = () => {
  const { userId } = useParams();
  const [user, setUser] = useState(null);
  const [posts, setPosts] = useState([]);
  


  useEffect(() => {
    fetch(`https://jsonplaceholder.typicode.com/users/${userId}`)
      .then((response => response.json()))
      .then((data => setUser(data)))
      .catch((error) => console.error('Error fetching country list:', error));

    fetch(`https://jsonplaceholder.typicode.com/posts?userId=${userId}`)
      .then(response => response.json())
      .then(data => {
        return (
          setPosts(data)
          // console.log(data)
        )
      });


  }, [userId]);

  return (
    <div className='main-container'>
      {user && (
        <div className='profile-main-wrap'>
          <Link to="/" className='back-url'>
            <button className='back-btn' >Back</button>
          </Link>
          <div className='dropdown-timer'>
            <ProfilePage />
          </div>
          <div className='user-profile-container'>
            <h1>{user.name}'s Profile</h1>
            <div className='user-profile-details'>
              <section>
                <h3>User Details</h3>
                <p>{`Name: ${user.name}`}</p>
                <span>{`Username: ${user.username}`}</span>|
                <span>{`Catch Phrase: ${user.company.catchPhrase}`}</span>
              </section>
              <section>
                <h3>Address</h3>
                <p>{`Street: ${user.address.street}`}</p>
                <span>{`Email: ${user.email}`}</span>|
                <span>{`Phone: ${user.phone}`}</span>
              </section>
            </div>
          </div>
          <div className='posts-container-wrap'>
            {posts.map(post => (
              <div key={post.id} className='post-container'>
                <div className='title'>{post.title}</div>
                <div className='post'>{post.body}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default UserProfile;



