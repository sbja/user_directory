import React, { useState, useEffect } from 'react';
import './UserDirectory.scss'

const ProfilePage = () => {
  const [countries, setCountries] = useState([]);
  const [selectedCountry, setSelectedCountry] = useState('America/New_York'); 
  const [currentTime, setCurrentTime] = useState('');
  const [clockPaused, setClockPaused] = useState(false);

  useEffect(() => {
    const fetchCountries = async () => {
      try {
        const response = await fetch('http://worldtimeapi.org/api/timezone');
        const data = await response.json();
        setCountries(data);
      } catch (error) {
        console.error('Error fetching country list:', error);
      }
    };

    fetchCountries();
  }, []);

  useEffect(() => {
    const fetchCurrentTime = async () => {
      try {
        const response = await fetch(`http://worldtimeapi.org/api/timezone/${selectedCountry}`);
        const data = await response.json();
        setCurrentTime(data.utc_datetime);
      } catch (error) {
        console.error('Error fetching current time:', error);
      }
    };

    if (!clockPaused) {
      const intervalId = setInterval(fetchCurrentTime, 1000); 

      return () => clearInterval(intervalId);
    }
  }, [selectedCountry, clockPaused]);

  const handleCountryChange = (event) => {
    setSelectedCountry(event.target.value);
  };

  const handlePauseButtonClick = () => {
    setClockPaused((prevPaused) => !prevPaused);
  };

  return (
    <div className='clock-main-wrap'>
        <label htmlFor="countrySelector">Select Country: </label>
        <select id="countrySelector"  value={selectedCountry} onChange={handleCountryChange}>
          <option value="">Select a country</option>
          {countries.map((country) => (
            <option key={country} value={country}>
              {country}
            </option>
          ))}
        </select>
        <p>{currentTime}</p>
        <button onClick={handlePauseButtonClick}>{clockPaused ? 'Start' : 'Pause'}</button>
    </div>
  );
};

export default ProfilePage;