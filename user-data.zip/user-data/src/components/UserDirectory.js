import React, { useState, useEffect } from 'react';
import UserCard from './UserCard';
import axios from 'axios';
import "./UserDirectory.scss"

const UserDirectory = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/users')
      .then((response) =>
        setUsers(response.data)
        // console.log(response)
      )
      .catch((error) => console.error('Error fetching user list:', error));
  }, []);

  return (
    <div className='user-dir-main-wrap'>
      <h1>User Directory</h1>
      <div className='user-dir-container'>
        {users.map((user) => (
          <UserCard key={user.id} user={user} />
        ))}
      </div>
    </div>
  );
};

export default UserDirectory;