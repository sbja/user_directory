import React from 'react';
import { Link } from 'react-router-dom';
import "./UserCard.scss"

const UserCard = ({ user }) => (
    <div className='main-card-wrap-container'>
        <Link to={`/user/${user.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
            <article>
                <figure>
                    <div className='user-post-container'>
                        <h2>{user.name}</h2>
                        <p>{`Posts: ${user.company.bs}`}</p>
                    </div>
                </figure>
            </article>
        </Link>


    </div>
);

export default UserCard;